class CategoriesModel {
  final String id, name, image;

  CategoriesModel({
    required this.id,
    required this.name,
    required this.image,
  });
}